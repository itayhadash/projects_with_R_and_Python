######################
# FILE : user_input_compute_mean.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex2 2018-2019
# DESCRIPTION : a function that compute mean as a respond to user input
######################

import compute_mean


def user_input_compute_mean():
    numbers = input("Please enter two numbers, x and y: ")
    # separate between the two numbers using split.
    n = numbers.split(' ')
    # "if not" is used to check if the inputs are numbers.
    if not n[0].isdigit() and n[1].isdigit():
        return None
    avg = input("Please enter (A)rithmetic, (G)eometric or (H)armonic: ")
    # calculate the mean as reqwested by the user input and if there is not a letter
    # returns none
    if avg == "A":
        print("The arithmetic mean of " + (n[0]) + " and "+(n[1])+" is "
                +str(compute_mean.compute_mean(int(n[0]),int(n[1]),"A")))
    elif avg == "G":
        print("The geometric mean of " + (n[0]) + " and "+(n[1])+" is "
              +str(compute_mean.compute_mean(int(n[0]),int(n[1]),"G")))
    elif avg == "H":
        print("The harmonic mean of " + (n[0]) + " and " +(n[1])+" is "
                +str(compute_mean.compute_mean(int(n[0]),int(n[1]),"H")))
    else:
        return None

