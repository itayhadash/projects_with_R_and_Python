######################
# FILE : fancy_arithmetic_mean.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex2 2018-2019
# DESCRIPTION : a function that compute an arithmetic mean according to a user input
######################



def fancy_arithmetic_mean():
    num = input("Please enter a number of numbers (1-5): ")
    # create a
    counter = 1
    avg = []
    if int(num) > 5 or int(num) < 1 or int(num) == str(num):
        print("The number you entered is not between 1 and 5, goodbye!")
    else:
        print("Please enter the numbers, one in each line ")
        while int(counter) <= int(num):
            n = input()
            counter += 1
            avg.append(int(n))
        print("The arithmetic mean of the numbers is " + str((sum(avg)/int(num))))
