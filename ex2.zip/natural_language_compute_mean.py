######################
# FILE : natural_language_compute mean.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex2 2018-2019
# DESCRIPTION : a function that compute three types of mean as a respond to free text
######################
# import a module from the first task
import compute_mean


def natural_language_compute_mean(text):
    # the len of the the text to check if the sentens is in the right.
    if len(text)<=30:
        name = text.split(' ')
    else:
        return None
    if name[2]!= "mean":
        return None
    if name[3]!= "of":
        return None
    if name[0]!= "Compute":
        return None
    # the ',' is used in the original sentants and used now to separate the two numbers.
    if ',' in name[4]:
        numbers = name[4].split(',')
    else:
        return None
    # each "if" is used to calculate each mean if the means word is used in the sentans
    if name[1]=="arithmetic" and numbers[0].isdigit() and numbers[1].isdigit():
        return int(numbers[0]),int(numbers[1])\
                ,int(compute_mean.compute_mean(int(numbers[0]),int(numbers[1]),"A"))
    elif name[1]=="geometric":
        return int(numbers[0]),int(numbers[1])\
                ,int(compute_mean.compute_mean(int(numbers[0]),int(numbers[1]),"G"))
    elif name[1]=="harmonic":
        return int(numbers[0]),int(numbers[1])\
            ,int(compute_mean.compute_mean(int(numbers[0]),int(numbers[1]),"H"))
    else:
        return None
