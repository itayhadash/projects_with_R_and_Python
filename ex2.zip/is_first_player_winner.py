######################
# FILE : is_first_player_winner.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex2 2018-2019
# DESCRIPTION :  a two player game that calculate three types of means and chooses the winner
#  according to the size of the mean
######################

import compute_mean


def is_first_player_winner(p1n1,p1n2,p2n1,p2n2):
    # checking if the users inputs are numbers.
    if p1n1!=int(p1n1) or p1n2!=int(p1n2) or p2n1!=int(p2n1) or p2n2!=int(p2n2):
        return None
    x = compute_mean.compute_mean(p1n1,p1n2,"A")
    y = compute_mean.compute_mean(p2n1,p2n2,"A")
    z = compute_mean.compute_mean(p1n1,p1n2,"G")
    q = compute_mean.compute_mean(p2n1,p2n2,"G")
    t = compute_mean.compute_mean(p1n1,p1n2,"H")
    v = compute_mean.compute_mean(p2n1,p2n2,"H")
    # compute each mean whit an import muodle and
    if ((int(x - y) + int(z - q) + int(t - v))) >= 0:
        return True
    else :
        return False

