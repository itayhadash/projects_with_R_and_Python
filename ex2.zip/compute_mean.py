######################
# FILE : compute_mean.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex2 2018-2019
# DESCRIPTION : a function that compute three types of means
######################

# a function that compute mean.
def compute_mean(x,y,z):
    # if the number is negitive the avarage will be worng there for
    # this term will make the function use onle positive numbers.
    if x<0 or y<0 :
        return None
    if z == "A" :
        return float((x+y)/2)
    elif z == "G" :
        return float((x*y)**0.5)
    # can't do a hermonic avarage whit x/y =0
    elif z == "H" and x!=0 and y!=0:
        return float(2/(1/x +1/y))
    else:
        return None



