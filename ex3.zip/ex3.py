#####################
# FILE : ex3.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex3 2018-2019
# DESCRIPTION : some functions that uses loops.
######################

import math

import turtle


def fancy_mean():
    print('Please enter the numbers, one in each line: ')
    # define the variables that will be used to sum the means
    arith_avg = 0
    geomet_avg = 1
    harmoni_avg = 0
    t = 0
    # variables that will be used as  boolian expresion in order to stop
    # the loop
    b = 0
    n = input()
    while b == 0:
        if n != '':
            # adds the input numbers to the variables
            arith_avg += float(n)
            geomet_avg *= float(n)
            harmoni_avg += 1/(float(n))
            # t is used as a "counter" that will be used to calculate the mean.
            t += 1
            n = input()
        if t == 0 :
            # if there won't be numbers t will also break the function.
            return None
        if n == '':
            # b is used to break the loop.
            b += 1
    print('The arithmetic mean of the numbers is '+ str(round(float((arith_avg)/t),4)))
    print('The geometric mean of the numbers is '+ str(round(math.pow(geomet_avg,1/t),4)))
    print('The harmonic mean of the numbers is '+ str(round(t/harmoni_avg,4)))

def perimeter(x,y):
    # two variables that will count the distance
    # w will count the all the distance between the first value and the last value in the range.
    # and sum will count the distance between the first and the lest value.
    t = 0
    w = 0
    # a variable used to express the last and the first value in both lists in order
    # for the code to be understandable
    # because both lists must be in the same length
    for p in range(0,len(x)-1):
        # calculate the distance between the first and last values
        w += math.sqrt((math.pow(x[p]-x[p+1],2)) + math.pow(y[p]-y[p+1],2))
        # because the loop skips the first and last value of range
        # they will be added in the end of the loop
    t += math.sqrt(math.pow(x[0]-x[len(x)-1],2) + math.pow(y[0]-y[len(y)-1],2))
    return (w + t)


def draw_spiral(t, orientation):
    # if is used to separate the orientation
    if orientation == "clock":
        # sets the turtle to the right angle
        turtle.left(90)
        for i in range(0, t-1):
            # the loop repeat a distance that getting longer
            # every interaction.
            turtle.forward(math.ceil(i/2)*5)
            turtle.right(90)
    elif orientation == "counterclock":
        # sets the turtle to the right angle
        turtle.right(90)
        for i in range(0, t-1):
            # the loop repeat a distance that getting longer
            # every interaction.
            turtle.forward(math.ceil(i/2)*5)
            turtle.left(90)

def cumulative_distribution(num_list,value_list):
    # the first variable sum the numbers that the value
    # is greater.
    total = 0
    # the second variable is the list of all the sums
    over = []
    # the loops will check how many numbers are lower than
    # the value
    for i in range(0,len(value_list)):
        for b in range(0,len(num_list)):
            if value_list[i] >= num_list[b]:
                # the sum will be add to the total value
                total += (1/len(num_list))
        # the sum value is append to the list
        over.append(total)
        # the total value return to 0 in order to sum the next value
        total = 0
    return over



def pascal_triangle(n):
    if n != int(n):
        return None
    # create two lists and a variable to be used in the function
    total = []
    one = []
    # loop creates a list that has the first 5 powers of 11 that are the first
    # 5 levels of the triangle
    # and append them to both lists
    for i in range(0,5):
        z = (int(math.pow(11, i)))
        o = [int(b) for b in str(z)]
        one.append(o)
        total.append(o)
    if n <= 5:
        return one[:n]
    # if n>5 the code will continue from the fifth power of 11 to the value
    # wanted
    for i in range(5, n):
        total.append([1])
        for t in range(1, i):
                # than the loop adds the number from the line above
                # to the number in the line below.
            total[i].append(total[i - 1][t - 1] + total[i - 1][t])
        if n != 0:
                # adds 1 to all the "left" side  of the triangle
                # so the next interaction in the loop will add the
                # right numbers in the levels of the triangle
            total[i].append(1)
            # change the first value back to 1
    total[0] = [1]
    return total


