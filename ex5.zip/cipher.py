from ngrams import *
import os

letters = "abcdefghijklmnopqrstuvwxyz"

# Create a dictionary from letters to letters based on Ceaser's code with a shift
def ceaser_code(shift):
    return {letters[i]: letters[(i + shift) % len(letters)] for i in range(len(letters))}


# Translate the plain text message into an encrypted one using the code dictionary
def encrypt(plaintext, code):
    return "".join([(code[c] if c in code else c) for c in plaintext])


# Invert substition code
def inverse_code(code):
    return {code[c]:c for c in code}


# Translate the encrypted message into plain text using the code dictionary
def decrypt(cipher, code):
    return encrypt(cipher, inverse_code(code))



# 6. Build language model from file
def build_language_model(language_filename, k):
    # the function open the file
    # read the file
    # replace "\n" whit " "
    # using compute_ngram_frequency to compute the frequency of the string
    if os.path.isfile(language_filename):
        t = open(language_filename)
    else:
        return None
    q = t.read()
    if q =="":
        return None
    r = q.replace("\n"," ")
    w = compute_ngram_frequency(r,k)
    return w

    pass


# 7. Compute distance
def compute_ngram_distance(dict1, dict2):
    counter=0
    # using a loop to check if a key is in both dicts
    # and if so compute the distance and adds the distance to the counter
    # if a key is only in one dict the loop will add the key value squerd
    # to the counter
    if len(dict1)>=len(dict2):
        for key in dict1:
            if key in dict2:
                counter += (dict1[key]-dict2[key])**2
            else:
                counter += (dict1[key])**2

        for key in dict2:
            if key not in dict1:
                counter += (dict2[key])**2

    if len(dict1)<len(dict2):
        for key in dict2:
            if key in dict1:
                counter+= (dict2[key]-dict1[key])**2
            else:
                counter += (dict2[key])**2

        for key in dict1:
            if key not in dict2:
                counter+=(dict1[key])**2

    return counter
    pass


# 8. Break ceaser code by trying all different shifts
def break_ceaser_code(cipher, language_ngram, k):
    t =str.lower(cipher)
    dist=[]
    # using a loop to compute all the
    # possible distances(whit all lower letters)
    # for each ceaser code dict
    # and adds them to the dist list
    for i in range(0,26):
        z = ceaser_code(i)
        w =decrypt(t,z)
        e = compute_ngram_frequency(w,k)
        p = compute_ngram_distance(e,language_ngram)
        dist.append(p)

    l = dist.index(min(dist))
    caplital =[]
    # using a loop to compute all the
    # possible distances(whit capital letters)
    # for each ceaser code dict
    # and adds them to the dist list
    for i in range(0,26):
        z = ceaser_code(i)
        w =decrypt(cipher,z)
        e = compute_ngram_frequency(w, k)
        p = compute_ngram_distance(e, language_ngram)
        caplital.append(p)

    k = caplital.index(min(caplital))
    f = decrypt(t,ceaser_code(l))
    d = decrypt(cipher,ceaser_code(k))
    y =""
    # the last loop checks if the original cipher has a capital letter
    # which the the decrypt cipher doest have
    # the loop will make the letter in the decrypt cipher a capital letter
    for i in range(0,len(d)):
        if str(d[i]) == str.capitalize(d[i]):
            y+= str(str.capitalize(f[i]))
        elif str(d[i]) != str(str.capitalize(d[i])):
            y+=f[i]

    return [y,l]
    pass


# 9. Find the best permutation substitution code by sorting frequencies and decrypt text
def break_code(cipher, language_ngram):
    f = str.lower(cipher)
    a = compute_ngram_frequency(f, 1)
    b = language_ngram
    d ={}
    # chance the cipher and the language_ngram by swapping the values whit the keys
    swapa = inverse_code(a)
    swapb = inverse_code(b)
    # takes each swapped dict max key
    # and creates a new dict whit each max value
    while swapa !={} or swapb!= {}:
        t = max(swapa)
        z = max(swapb)
        d[swapa[t]] = swapb[z]
        del swapa[t]
        del swapb[z]

    dec = decrypt(f,d)
    ending =""
    # the last loop checks if the original cipher has a capital letter
    # which the the decrypt cipher doest have
    # the loop will make the letter in the decrypt cipher a capital letter
    for i in range(0,len(cipher)):
        if str(cipher[i]) == str(str.capitalize(f[i])):
            ending+= str(str.capitalize(dec[i]))
        if str(cipher[i]) != str(str.capitalize(cipher[i])):
            ending+= str(dec[i])

    return [ending,d]
    pass