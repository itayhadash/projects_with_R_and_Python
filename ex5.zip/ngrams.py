# 1. Compute ngram statistics for text
def compute_ngram_frequency(text, n):
    code_letters = []
    letters =[]
    z = ""
    d = {}
    y = 0
    t = n
    new_text = str.lower(text)
    # create a  two lists.
    # letters - a list of all the letters in the text
    # code_letters - a list of all the single letters in the text
    # for example "hello" will become [h,e,l,o]
    if n == 1:
        for i in range(0,len(new_text)):
            if new_text[i] in "abcdefghijklmnopqrstuvwxyz":
                letters.append(new_text[i])
        for i in range (0,len(new_text)):
            if new_text[i] in "abcdefghijklmnopqrstuvwxyz" and new_text[i] not in code_letters:
                code_letters.append(new_text[i])
    # compute the frequency of the letters by using the letters list and the code_letters list
    # and using y parameter as a counter to check how many times a letter in code_letters is in
    # letters list
        for i in range(0,len(code_letters)):
             for w in range(0,len(letters)):
                 if code_letters[i] == letters[w]:
                     y+=1
             d[code_letters[i]] = y/len(letters)
             y = 0
        return d
    # if n>1 the loop adds to the letters list all the
    # possible combinations
    # of letters by "cutting" the words in to small segments
    elif n>1:
        for i in range(0, len(new_text)):
            if new_text[i] in "abcdefghijklmnopqrstuvwxyz" or new_text[i] == " ":
                z+=new_text[i]
    while t <= len(z):
        if " " not in z[y:t]:
            letters.append(z[y:t])
            t+=1
            y+=1
        if " " in z[y:t]:
            t+=1
            y+=1
    # code_letters list is used in this loop
    # to get all the "types" of combinations
    # for example the word "banana" (n =2) will be in code_letters
    # list as [ba,an,na]
    for i in range(0,len(letters)):
        if letters[i] not in code_letters:
            code_letters.append(letters[i])

    y=0
    # compute the frequency by of the code_letters
    # by using y parameter as a counter to check how many times a letter in code_letters is in
    # letters list
    for i in range(0, len(code_letters)):
        for w in range(0, len(letters)):
            if code_letters[i] == letters[w]:
                y += 1
        d[code_letters[i]] = y / len(letters)
        y = 0

    return d
    pass


# 2. Concatenate items of dictionary to one string
def ngram_dict_to_string(d):
    z=""
    w =[]
    # create a list of all the keys
    for key in d:
        w.append(key)
    # by using a loop that adds the key to the value of the key
    # in order to create a string the resemble the dictionary
    for i in range(0,len(w)):
        if i<(len(w)-1):
            z+=w[i]+":"+str(d[w[i]])+" "
        elif i == (len(w)-1):
            z += w[i] + ":" + str(d[w[i]])

    return z
    pass


# 3. split string to dictionary
def string_to_ngram_dict(s):
    # first the function takes the string and splits it in " "
    # and creating a list(by using the split)
    w = str(s).split(" ")
    d={}
    # the loop using another split each part of the w list in ":"
    # and creating a new dictionary by using b[0] as the key and b[1] as the value
    for i in range(0,len(w)):
        b = w[i].split(":")
        t = float(b[1])
        d[b[0]]= t

    return d
    pass


# 4. Save to file
def write_ngram_dict(dict, filename):
    z=""
    # using the ngram dictionary to string function to turn a dictionary in to a string
    # and then write in to a txt file
    z += ngram_dict_to_string(dict)
    r = open(filename,"w")
    r.write(z)
    pass


# 5. Load from file
def load_ngram_dict(filename):
    # the function open the file
    # read the file
    # replace "\n" whit " "
    # and them using string to ngram dictionary to create a dictionary
    q = open(filename,"r")
    t = q.read()
    w = t.replace("\n"," ")
    r = string_to_ngram_dict(w)
    return r
    pass






