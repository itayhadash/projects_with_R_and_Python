#####################
#FILE : math_print.py
#WRITER : Itay Hadash , 25195, 206094278
#EXERCISE : intro2cs ex1 2018-2019
#DESCRIPTION : three fanctions that calculate some math vriabales
######################
import math
# this function will calculate cos(45)
def cos_45():
    print(math.cos(45))
#  this function wil calculate ln(20)
def natural_log_20():
    print(math.log(20))
# this function will calculate a triangle area in which the base=12 and the height to the base=3
def triangle_area_3x12():
    print(3*12/2)

