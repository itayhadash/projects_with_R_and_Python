#####################
#FILE : hello.turtle.py
#WRITER : Itay Hadash , 25195, 206094278
#EXERCISE : intro2cs ex1 2018-2019
#DESCRIPTION : a progran that useing turtle moudle to draw stars
# on python grafics screen
######################

import turtle
# Those lines will draw one star
def draw_star():
    turtle.forward(20)
    turtle.right(144)
    turtle.forward(20)
    turtle.right(144)
    turtle.forward(20)
    turtle.right(144)
    turtle.forward(20)
    turtle.right(144)
    turtle.forward(20)


#Those line will draw a star cluster
def draw_star_cluster():
    draw_star()
    turtle.up()
    turtle.forward(30)
    turtle.left(120)
    turtle.down()
    draw_star()
    turtle.up()
    turtle.forward(30)
    turtle.left(120)
    turtle.down()
    draw_star()

# Those lines will draw a group of star clustes
def draw_sky():
    draw_star_cluster()
    turtle.left(10)
    turtle.up()
    turtle.forward(150)
    turtle.down()
    draw_star_cluster()
    turtle.left(10)
    turtle.up()
    turtle.forward(150)
    turtle.down()
    draw_star_cluster()
    turtle.left(270)
    turtle.up()
    turtle.forward(150)
    turtle.down()
    draw_star_cluster()
    turtle.left(270)
    turtle.up()
    turtle.forward(150)
    turtle.down()
    draw_star_cluster()


turtle.done()