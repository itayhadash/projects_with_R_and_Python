# Implement crossword solving
#####################
# FILE : ex4.py
# WRITER : Itay Hadash , 25195, 206094278
# EXERCISE : intro2cs ex4 2018-2019
# DESCRIPTION : a crossword game
######################

import random
from crossword_helper import *


# 1. Identify all black squares. Output should be list of lists of size: [size[0], size[1]]
def add_blacks(H_list, V_list, size):
    if len(size)>2:
        return False
    if size[0] == str(size[0]) or size[1] == str(size[1]):
        return False
    # i began by creating three lists total - for total of all the coordinates
    # p list for H_list solution coordinates
    # c list for V_list solution coordinates
    total = []
    p = []
    c = []
    # the loop append to the total list all the total of coordinates
    # by creating a sub list for each coordinates
    for x in range(0,size[0]):
        for y in range(0,size[1]):
            total.append([x,y])
    # this loop append to the p list the total of coordinates of solutions
    # for the H_list(for example loop will become [[1,0],[1,1],[1,2],[1,3]])
    if H_list != []:
        for i in range(0,len(H_list)):
            p.append([[H_list[i][0],H_list[i][1]+q] for q in range(0,len(H_list[i][3]))])
    # this loop append to the c list the total of coordinates of solutions
    # for the V_list(for example all will become [[0,0],[1,0],[2,0]])
    if V_list !=[]:
        for i in range(0,len(V_list)):
            c.append([[V_list[i][0]+q,V_list[i][1]] for q in range(0,len(V_list[i][3]))])
    # this loop will check if coordinates of p == coordinates of total
    # and if so, will turn the slot to a white slot
    for t in range(0,len(H_list)):
        for i in range(0,len(p[t])):
            if p[t][i] in total:
                total[total.index(p[t][i],0,len(total))]= 0
    # this loop will check if coordinates of c == coordinates of total
    # and if so, will turn the slot to a white slot
    for t in range(0,len(V_list)):
        for i in range(0,len(c[t])):
            if c[t][i] in total:
                total[total.index(c[t][i],0,len(total))] = 0
    # if there are any coordinates in total that are not white
    # this loop will make them black
    for t in range(0,len(total)):
        if total[t] != 0:
            total[t] = 1
    # this loop take the new list of total that now have only zeros and ones
    # and rearange them to the size of the crossword
    z = [total[x:x + size[1]] for x in range(0, len(total), size[1])]
    return z
    pass


# 2. Check if answer is valid
def crossword_isvalid(ans, numdef, H_list, V_list):
    if len(numdef) != 2:
        return False
    # i began by creating two lists
    # p list for H_list solution coordinates
    # c list for V_list solution coordinates
    p = []
    c = []
    # this loop append to the p list the total of coordinates of solutions
    # for the H_list(for example loop will become [[1,0],[1,1],[1,2],[1,3]])
    for i in range(0,len(H_list)):
        p.append([[H_list[i][0],H_list[i][1]+q] for q in range(0,len(H_list[i][3]))])
    # this loop append to the c list the total of coordinates of solutions
    # for the V_list(for example all will become [[0,0],[1,0],[2,0]])
    for i in range(0,len(V_list)):
        c.append([[V_list[i][0]+q,V_list[i][1]] for q in range(0,len(V_list[i][3]))])
    # checks if the solution that the user gave is in the same length
    # as the answer in the definitions number
    # (numdef[0] will match the index in p list
    if numdef[1] == "H" and len(ans) != len(p[numdef[0]]):
        print("Error: Wrong length!")
        return False
    # checks if the answer that the user gave is in the same length
    # as the answer in the definitions number
    # (numdef[0] will match the index in c list
    if numdef[1] == "V" and len(ans) != len(c[numdef[0]]):
        print("Error: Wrong length!")
        return False
    if V_list == []:
        return True
    if H_list == []:
        return True
    # checks if the answer that the user gave have the same letter
    # as the answer that crosses the users answer by checking three conditions
    if numdef[1] == "H":
        for i in range(0,len(V_list)):
            for t in range(0,len(ans)):
                # 1) if the letter of the answer q is in p/c depending if the answers type(if numdef[1] == "H"
                # the loop will search c list(V_list solutions and the oposit
                # 2) if the user gave a solution for the question that crosses the answer(if the user did not gave
                # a solution that means that any answer will not give a mismatch
                # 3) the answer does not eqal the letter in the opose list(ans in H_list will check V_list)
                if p[numdef[0]][t] in c[i] and len(V_list[i]) == 5 and ans[t] != V_list[i][4][
                    c[i].index(p[numdef[0]][t])]:
                    print("Error: Mismatch!")
                    return False
                else:
                    return True
    elif numdef[1] == "V":
        for i in range(0, len(H_list)):
            for t in range(0, len(ans)):
                # 1) if the letter of the answer q is in p/c depending if the answers type(if numdef[1] == "V"
                # the loop will search c list(V_list solutions and the oposit
                # 2) if the user gave a solution for the question that crosses the answer(if the user did not gave
                # a solution that means that any answer will not give a mismatch
                # 3) the answer does not eqal the letter in the opose list(ans in V_list will check H_list)
                if c[numdef[0]][t] in p[i] and len(H_list[i]) == 5 and ans[t] != H_list[i][4][
                    p[i].index(c[numdef[0]][t])]:
                    print("Error: Mismatch!")
                    return False
                else:
                    return True
    pass


# 3. Get status
def crossword_status(H_list, V_list):
    # starting whit three variables that count
    # wrong,missing and correct answers
    wrong = 0
    missing = 0
    correct = 0
    # count H_list definitions by and adds them to
    # the variables
    if H_list !=[]:
        for i in range(0,len(H_list)):
            if len(H_list[i]) == 5 and H_list[i][3] == H_list[i][4]:
                correct += 1
            if len(H_list[i]) == 5 and H_list[i][3] != H_list[i][4]:
                wrong += 1
            if len(H_list[i]) == 4:
                missing += 1
    # count V_list definitions by and adds them to
    # the variables
    if V_list !=[]:
        for i in range(0,len(V_list)):
            if len(V_list[i]) == 5 and V_list[i][3] == V_list[i][4]:
                correct += 1
            if len(V_list[i]) == 5 and V_list[i][3] != V_list[i][4]:
                wrong += 1
            if len(V_list[i]) == 4:
                missing += 1
    # returns the total
    return [correct,wrong,missing]
    pass


# 4. Ask a random definition from user
def random_def(H_list, V_list):
    w = []
    # using the former loop to check if there are any un solved
    # if so the loop will create a list of all the unsolved
    if crossword_status(H_list,V_list)[2] == 0:
        print("No more definitions left")
        return False
    else:
        for i in range(0,len(H_list)):
            if len(H_list[i]) == 4:
                w.append([i,"H",":",H_list[i][2],H_list[i][3]])

        for i in range(0,len(V_list)):
            if len(V_list[i]) == 4:
                w.append([i,"V",":",V_list[i][2],V_list[i][3]])
    # random.sample is used to pick a random unsolved question
    # ans is used as an input for the answer
    # and numdef create the list of the number of def and type("H"/"V")
    q = random.sample(w,1)
    ans =input(str(q[0][0])+str(q[0][1])+str(q[0][2])+" "+str(q[0][3])+" "+"("+str((len(q[0][4])))+")")
    numdef = [q[0][0],str(q[0][1])]
    i = 0
    if crossword_isvalid(ans, numdef, H_list, V_list) == False:
        return False
    while i <= max(len(H_list),len(V_list)):
        # if the question is a part of H_list or V_list and ans in valid
        # the loop will append the answer to the right list in H_list or V_list
        if q[0][3] in H_list[i] and crossword_isvalid(ans, numdef, H_list, V_list) == True :
            H_list[i].append(ans)
            return True
        elif q[0][3] in V_list[i] and crossword_isvalid(ans, numdef, H_list, V_list) == True :
            V_list[i].append(ans)
            return True
        elif q[0][3] not in H_list[i] or V_list[i] and crossword_isvalid(ans, numdef, H_list, V_list) == True:
            i+=1
        elif i == max(len(H_list),len(V_list)) and q[0][3] not in H_list[i] or V_list:
            return False

    pass


# 5. Write definitions to file
def write_defs(H_list, V_list, textfile):
    # opens a txt file to insert the output
    defs_output = open(textfile,"w")
    for i in range(0,len(H_list)):
        # if if the user answer the question the loop will append the users answer whit the definition
        # to the txt file
        if len(H_list[i]) == 5:
            defs_output.write(
                str(i) + " " + "H: " + str(H_list[i][0]) + "," + str(H_list[i][1]) + " : " + H_list[i][2] + " : " +
                H_list[i][3] + " : " +
                H_list[i][4] + "\n")
        # else, the loop will append the rest of the definition without the answer
        elif len(H_list[i]) == 4:
            defs_output.write(
                str(i)+" " + "H: " + str(H_list[i][0]) + "," + str(H_list[i][1]) + " : " + H_list[i][2] + " : " +
                H_list[i][3]  + "\n")
    # if if the user answer the question the loop will append the users answer whit the definition
    # to the txt file
    for i in range(0, len(V_list)):
        if len(V_list[i]) == 5:
            defs_output.write(
                str(i) + " " + "V: " + str(V_list[i][0]) + "," + str(V_list[i][1]) + " : " + V_list[i][2] + " : " +
                V_list[i][3] + " : " +
                V_list[i][4] + "\n")
            # else, the loop will append the rest of the definition without the answer
        elif len(V_list[i]) == 4:
            defs_output.write(
                str(i)+" " + "V: " + str(V_list[i][0]) + "," + str(V_list[i][1]) + " : " + V_list[i][2] + " : " +
                V_list[i][3]  + "\n")

        defs_output.close()
        pass
